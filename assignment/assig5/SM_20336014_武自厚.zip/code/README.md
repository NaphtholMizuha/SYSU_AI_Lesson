# alpha-beta剪枝的中国象棋



#### 文件介绍

`main.py`是main函数的程序，需要运行这个文件。

其他`.py`文件都是各自的类，具体功能见实验报告。

`images`是有些所需的图片。



#### 代码运行

代码实现基于python3.8

需要安装`pygame`和`numpy`库。

```
pip install pygame
pip install numpy
```

运行`main.py`程序。
