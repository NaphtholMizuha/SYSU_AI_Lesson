# $k$-means 聚类算法

## 运行方式

```sh
python3 main.py
```

## 文件组成

- `main.py` 聚类算法
- `parse.py` 数据获取
- `figure.py` 结果绘图展示
- `data.txt` 数据源